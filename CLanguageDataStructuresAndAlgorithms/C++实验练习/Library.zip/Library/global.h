const int LIMIT = 3;

enum State { READER, LIB, SHELF };

class Object{
};